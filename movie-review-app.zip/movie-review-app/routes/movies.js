const express = require('express');
const router = express.Router();
const Movie = require('../models/Movie');

const predefinedMovies = [
    {
        title: 'Inception',
        year: 2010,
        image: 'https://m.media-amazon.com/images/M/MV5BMTMxNTMwODM0NF5BMl5BanBnXkFtZTcwODAyMTk2Mw@@._V1_.jpg',
        description: 'A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O.'
    },
    {
        title: 'The Dark Knight',
        year: 2008,
        image: 'https://m.media-amazon.com/images/M/MV5BMjAxMzY3NjQ5Nl5BMl5BanBnXkFtZTcwODAyMTk2Mw@@._V1_.jpg',
        description: 'When the menace known as the Joker emerges from his mysterious past, he wreaks havoc and chaos on the people of Gotham.'
    },
    {
        title: 'Interstellar',
        year: 2014,
        image: 'https://m.media-amazon.com/images/M/MV5BMjIxNTU4MzYzMF5BMl5BanBnXkFtZTgwMzM4ODI3MDE@._V1_.jpg',
        description: 'A team of explorers travel through a wormhole in space in an attempt to ensure humanity\'s survival.'
    },
    {
        title: 'The Matrix',
        year: 1999,
        image: 'https://m.media-amazon.com/images/M/MV5BNzQzOTk3NTAtNjQ5ZC00ZGVlLWE3MzUtODU3ZDU3ZmQzODU5XkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_.jpg',
        description: 'When a beautiful stranger leads computer hacker Neo to a forbidding underworld, he discovers the shocking truth.'
    },
    {
        title: 'Fight Club',
        year: 1999,
        image: 'https://m.media-amazon.com/images/M/MV5BMmEzYTYxYzgtNTc1My00NzllLTkxZTktNzQ5YjA3MzU3NjhlXkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_.jpg',
        description: 'An insomniac office worker and a devil-may-care soap maker form an underground fight club that evolves into much more.'
    },
    {
        title: 'Forrest Gump',
        year: 1994,
        image: 'https://m.media-amazon.com/images/M/MV5BMTk5OTk3MDI2N15BMl5BanBnXkFtZTcwODI2MjU3Mw@@._V1_.jpg',
        description: 'The presidencies of Kennedy and Johnson, the Vietnam War, the Watergate scandal and other historical events unfold from the perspective of an Alabama man with an IQ of 75.'
    },
    {
        title: 'The Shawshank Redemption',
        year: 1994,
        image: 'https://m.media-amazon.com/images/M/MV5BODU4MjU4OTM4Nl5BMl5BanBnXkFtZTgwNjYyNTU3MDE@._V1_.jpg',
        description: 'Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency.'
    },
    {
        title: 'Pulp Fiction',
        year: 1994,
        image: 'https://m.media-amazon.com/images/M/MV5BMTk4OTMzNjYwOF5BMl5BanBnXkFtZTgwNjk2MjA3MDE@._V1_.jpg',
        description: 'The lives of two mob hitmen, a boxer, a gangster and his wife, and a pair of diner bandits intertwine in four tales of violence and redemption.'
    },
    {
        title: 'The Godfather',
        year: 1972,
        image: 'https://m.media-amazon.com/images/M/MV5BM2MyNjYxNmYtYTAwNi00ZjQ1LThmNjItYmM2N2E1YzM1ZWM2XkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_.jpg',
        description: 'The aging patriarch of an organized crime dynasty transfers control of his clandestine empire to his reluctant son.'
    },
    {
        title: 'The Lord of the Rings: The Return of the King',
        year: 2003,
        image: 'https://m.media-amazon.com/images/M/MV5BNjViNWU4NDItYTQ5NC00NjU3LTg5YjAtOTM2ZWI2MjNmYTZiXkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_.jpg',
        description: 'Gandalf and Aragorn lead the World of Men against Sauron\'s army to draw his gaze from Frodo and Sam as they approach Mount Doom with the One Ring.'
    },
];

// Seed the database with predefined movies (run this only once)
router.post('/seed', async (req, res) => {
    try {
        // Check if movies already exist to avoid duplicates
        const existingMovies = await Movie.find();
        if (existingMovies.length > 0) {
            return res.status(400).json({ message: 'Movies have already been seeded' });
        }

        await Movie.insertMany(predefinedMovies);
        res.status(201).json({ message: 'Movies seeded successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get all movies
router.get('/', async (req, res) => {
    try {
        const movies = await Movie.find();
        res.json(movies);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;