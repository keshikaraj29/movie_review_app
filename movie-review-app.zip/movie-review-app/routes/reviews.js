// routes/reviews.js
const express = require('express');
const router = express.Router();
const Review = require('../models/Review');
const authMiddleware = require('../middlewares/auth');

// Add a new review (requires authentication)
router.post('/:movieId', authMiddleware, async (req, res) => {
    const { movieId } = req.params;
    const { reviewText } = req.body;
    const userId = req.user.id;

    try {
        const newReview = new Review({ userId, movieId, reviewText });
        await newReview.save();
        res.status(201).json(newReview);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Get all reviews for a movie
router.get('/:movieId', async (req, res) => {
    const { movieId } = req.params;

    try {
        const reviews = await Review.find({ movieId }).populate('userId', 'username');
        res.json(reviews);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Edit a review (requires authentication)
router.put('/:reviewId', authMiddleware, async (req, res) => {
    const { reviewId } = req.params;
    const { reviewText } = req.body;
    const userId = req.user.id;

    try {
        const review = await Review.findOne({ _id: reviewId, userId });
        if (!review) {
            return res.status(404).json({ error: 'Review not found or not authorized' });
        }

        review.reviewText = reviewText;
        await review.save();
        res.json(review);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Delete a review (requires authentication)
router.delete('/:reviewId', authMiddleware, async (req, res) => {
    const { reviewId } = req.params;
    const userId = req.user.id;

    try {
        const review = await Review.findOneAndDelete({ _id: reviewId, userId });
        if (!review) {
            return res.status(404).json({ error: 'Review not found or not authorized' });
        }

        res.json({ message: 'Review deleted successfully' });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

module.exports = router;