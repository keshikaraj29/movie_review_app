// models/Movie.js
const mongoose = require('mongoose');

const MovieSchema = new mongoose.Schema({
    title: { type: String, required: true },
    year: { type: Number, required: true },
    image: { type: String, required: true },
    description: { type: String }  // Non-mandatory description field
});

module.exports = mongoose.model('Movie', MovieSchema);