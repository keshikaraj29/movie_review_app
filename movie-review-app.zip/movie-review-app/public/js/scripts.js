document.addEventListener('DOMContentLoaded', () => {
    const loginLink = document.getElementById('login-link');
    const signupLink = document.getElementById('signup-link');
    const logoutLink = document.getElementById('logout-link');
    const loginForm = document.getElementById('login-form');
    const signupForm = document.getElementById('signup-form');
    const movieList = document.getElementById('movie-list');
    const reviewSection = document.getElementById('review-section');

    loginLink.addEventListener('click', () => {
        loginForm.style.display = 'block';
        signupForm.style.display = 'none';
        movieList.style.display = 'none';
        reviewSection.style.display = 'none';
    });

    signupLink.addEventListener('click', () => {
        signupForm.style.display = 'block';
        loginForm.style.display = 'none';
        movieList.style.display = 'none';
        reviewSection.style.display = 'none';
    });

    logoutLink.addEventListener('click', () => {
        fetch('/api/auth/logout', { method: 'POST' })
            .then(() => {
                logoutLink.style.display = 'none';
                loginLink.style.display = 'block';
                signupLink.style.display = 'block';
                movieList.style.display = 'none';
                reviewSection.style.display = 'none';
            });
    });

    document.getElementById('login').addEventListener('submit', (e) => {
        e.preventDefault();
        const email = document.getElementById('login-email').value;
        const password = document.getElementById('login-password').value;

        fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        })
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    alert(data.error);
                } else {
                    loginForm.style.display = 'none';
                    logoutLink.style.display = 'block';
                    loginLink.style.display = 'none';
                    signupLink.style.display = 'none';
                    loadMovies();
                }
            });
    });

    document.getElementById('signup').addEventListener('submit', (e) => {
        e.preventDefault();
        const username = document.getElementById('signup-username').value;
        const email = document.getElementById('signup-email').value;
        const password = document.getElementById('signup-password').value;

        fetch('/api/auth/signup', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, email, password })
        })
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    alert(data.error);
                } else {
                    signupForm.style.display = 'none';
                    alert('User registered successfully. Please log in.');
                }
            });
    });

    function loadMovies() {
        fetch('/api/movies')
            .then(response => response.json())
            .then(movies => {
                const moviesContainer = document.getElementById('movies');
                moviesContainer.innerHTML = '';
                movies.forEach(movie => {
                    const movieCard = document.createElement('div');
                    movieCard.classList.add('movie-card', 'col-md-4');
                    movieCard.innerHTML = `
                        <img src="${movie.image}" alt="${movie.title}" class="img-fluid rounded">
                        <h3>${movie.title}</h3>
                        <p>${movie.year}</p>
                        ${movie.description ? `<p>${movie.description}</p>` : ''}
                        <button onclick="loadReviews('${movie._id}')">View Reviews</button>
                        <button class="download-button" onclick="startDownload(this)">Download</button>
                    `;
                    moviesContainer.appendChild(movieCard);
                });
                movieList.style.display = 'block';
            });
    }

    window.loadReviews = (movieId) => {
        fetch(`/api/reviews/${movieId}`)
            .then(response => response.json())
            .then(reviews => {
                const reviewsContainer = document.getElementById('reviews');
                reviewsContainer.innerHTML = '';
                reviews.forEach(review => {
                    const reviewCard = document.createElement('div');
                    reviewCard.classList.add('review-card');
                    reviewCard.innerHTML = `
                        <h3>${review.userId.username}</h3>
                        <p>${review.reviewText}</p>
                        <button onclick="editReview('${review._id}', '${review.reviewText.replace(/'/g, "\\'")}')">Edit</button>
                        <button onclick="deleteReview('${review._id}')">Delete</button>
                    `;
                    reviewsContainer.appendChild(reviewCard);
                });
                reviewSection.style.display = 'block';
                document.getElementById('add-review-form').style.display = 'block';
                document.getElementById('add-review-form').dataset.movieId = movieId;
            });
    };

    document.getElementById('add-review-form').addEventListener('submit', (e) => {
        e.preventDefault();
        const reviewText = document.getElementById('review-text').value;
        const movieId = document.getElementById('add-review-form').dataset.movieId;

        fetch(`/api/reviews/${movieId}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ reviewText })
        })
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    alert(data.error);
                } else {
                    loadReviews(movieId);
                }
            });
    });

    window.editReview = (reviewId, reviewText) => {
        const newReviewText = prompt('Edit your review:', reviewText);
        if (newReviewText) {
            fetch(`/api/reviews/${reviewId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ reviewText: newReviewText })
            })
                .then(response => response.json())
                .then(data => {
                    if (data.error) {
                        alert(data.error);
                    } else {
                        loadReviews(data.movieId);
                    }
                });
        }
    };

    window.deleteReview = (reviewId) => {
        if (confirm('Are you sure you want to delete this review?')) {
            fetch(`/api/reviews/${reviewId}`, { method: 'DELETE' })
                .then(response => response.json())
                .then(data => {
                    if (data.error) {
                        alert(data.error);
                    } else {
                        loadReviews(data.movieId);
                    }
                });
        }
    };

    window.startDownload = (button) => {
        button.disabled = true;
        button.textContent = 'Downloading...';

        // Simulate download animation
        setTimeout(() => {
            button.textContent = 'Download';
            button.disabled = false;
            alert('Download started!');
        }, 2000); // Simulate a 2-second download animation
    };

    // Load movies initially
    loadMovies();
});