function loadMovies() {
    fetch('/api/movies')
        .then(response => response.json())
        .then(movies => {
            console.log(movies); // Log the movie data to verify image paths
            const moviesContainer = document.getElementById('movies');
            moviesContainer.innerHTML = '';
            movies.forEach(movie => {
                const movieCard = document.createElement('div');
                movieCard.classList.add('movie-card', 'col-md-4');
                movieCard.innerHTML = `
                    <img src="${movie.image}" alt="${movie.title}" class="img-fluid rounded">
                    <h3>${movie.title}</h3>
                    <p>${movie.year}</p>
                    <button onclick="loadReviews('${movie._id}')">View Reviews</button>
                `;
                moviesContainer.appendChild(movieCard);
            });
            movieList.style.display = 'block';
        });
}